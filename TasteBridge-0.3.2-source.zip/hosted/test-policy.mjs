import assert from 'node:assert/strict';
import {rankGroup,feasible} from './lib/taste.ts';
const r=rankGroup([{a:9,b:8,c:1},{a:1,b:8,c:9}],['a','b','c']);assert.equal(r[0].id,'b');assert.equal(r[0].minimum,.5);
assert.throws(()=>rankGroup([{a:1,b:1},{a:2,b:1}],['a','b']));
assert.throws(()=>rankGroup([{a:1},{a:2,b:1}],['a','b']));
const c={price:20,reviewed:true,source:'Test only',observed:Date.now(),stepFree:true,veto:false};
assert.equal(feasible(c,30,true),null);assert.equal(feasible({...c,price:null},30,false),'Price is unknown');assert.equal(feasible({...c,price:NaN},30,false),'Price is unknown');assert.equal(feasible({...c,stepFree:null},30,true),'Step-free access is not confirmed');assert.equal(feasible({...c,veto:true},30,true),'Group veto');assert.equal(feasible({...c,observed:0},30,true),'Facts are older than 24 hours');assert.equal(feasible(c,10,false),'Over budget');
console.log('10 decision and constraint checks passed');
