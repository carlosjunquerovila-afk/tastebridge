import { sqliteTable, text, integer } from 'drizzle-orm/sqlite-core';
export const meter = sqliteTable('qloo_meter', { id: text('id').primaryKey(), used: integer('used').notNull().default(0) });
export const cache = sqliteTable('qloo_cache', { id: text('id').primaryKey(), payload: text('payload').notNull(), expires: integer('expires').notNull() });
