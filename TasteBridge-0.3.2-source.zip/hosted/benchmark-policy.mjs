import {rankGroup} from './lib/taste.ts';
const ids=['a','b','c'];const orders=[[0,1,2],[0,2,1],[1,0,2],[1,2,0],[2,0,1],[2,1,0]];
let improved=0,same=0,lower=0,loss=0,gain=0,changed=0,maxLoss=0;
for(const x of orders)for(const y of orders)for(const z of orders){
 const rows=[x,y,z].map(a=>Object.fromEntries(ids.map((id,i)=>[id,a[i]])));const ranked=rankGroup(rows,ids);const fair=ranked[0];const avg=[...ranked].sort((a,b)=>b.mean-a.mean||a.id.localeCompare(b.id))[0];
 if(fair.id!==avg.id)changed++;if(fair.minimum>avg.minimum)improved++;else if(fair.minimum===avg.minimum)same++;else lower++;
 gain+=fair.minimum-avg.minimum;loss+=avg.mean-fair.mean;maxLoss=Math.max(maxLoss,avg.mean-fair.mean);
}
console.log(JSON.stringify({scope:'Exhaustive synthetic strict ordinal preferences:3guests,3options,6^3=216. Not user satisfaction or Qloo/LLM benchmark. Benefits in minimum rank follow the policy objective by construction.',cases:216,selectionChanged:changed,minimumImproved:improved,minimumEqual:same,minimumLower:lower,averageMinimumGain:gain/216,averageMeanSacrifice:loss/216,maxMeanSacrifice:maxLoss,baseline:'Mean of within-query midranks; lexicographic entity-id tie-break on both policies.'},null,2));
if(lower)process.exit(1);
