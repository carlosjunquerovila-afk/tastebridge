export function rankGroup(matrix: Record<string,number>[], ids:string[]) {
 if(matrix.some(m=>ids.some(id=>!Number.isFinite(m[id])))) throw Error('Incomplete affinity evidence');
 if(matrix.some(m=>new Set(ids.map(id=>m[id])).size<2)) throw Error('No discriminating taste evidence. Try a different shortlist.');
 const ranks=matrix.map(m=>Object.fromEntries(ids.map(id=>[id,(ids.filter(j=>m[j]<m[id]).length+.5*(ids.filter(j=>m[j]===m[id]).length-1))/(ids.length-1)])));
 return ids.map(id=>({id,ranks:ranks.map(r=>r[id]),minimum:Math.min(...ranks.map(r=>r[id])),mean:ranks.reduce((s,r)=>s+r[id],0)/ranks.length})).sort((a,b)=>b.minimum-a.minimum||b.mean-a.mean||a.id.localeCompare(b.id));
}
export function feasible(c:any,budget:number,access:boolean) {
 if(c.veto===true)return 'Group veto';
 if(typeof c.price!=='number'||!Number.isFinite(c.price)||c.price<0)return 'Price is unknown';
 if(c.price>budget)return 'Over budget';
 if(access&&c.stepFree!==true)return 'Step-free access is not confirmed';
 if(c.reviewed!==true||typeof c.source!=='string'||c.source.trim().length<3)return 'Confirm current facts and record their source';
 if(!Number.isFinite(c.observed)||Date.now()-c.observed<0||Date.now()-c.observed>86400000)return 'Facts are older than 24 hours';
 return null;
}
