import {env} from 'cloudflare:workers';
import {rankGroup,feasible} from '../../../lib/taste';
const ORIGIN='https://hackathon.api.qloo.com';
const headers={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff'};
const enc=new TextEncoder();
const hex=(a:ArrayBuffer)=>Array.from(new Uint8Array(a),b=>b.toString(16).padStart(2,'0')).join('');
const digest=async(s:string)=>hex(await crypto.subtle.digest('SHA-256',enc.encode(s)));
async function sign(s:string,key:string){const k=await crypto.subtle.importKey('raw',enc.encode(key),{name:'HMAC',hash:'SHA-256'},false,['sign']);return hex(await crypto.subtle.sign('HMAC',k,enc.encode('TasteBridge-entity-v1:'+s)));}
async function issue(entity:any,key:string){const payload=JSON.stringify({...entity,expires:Date.now()+3600000});return {entity,proof:btoa(unescape(encodeURIComponent(payload)))+'.'+await sign(payload,key)};}
async function verify(proof:string,key:string){
 if(typeof proof!=='string'||proof.length>12000)throw Error('Review a returned search result first');
 const [b,s]=proof.split('.');const payload=decodeURIComponent(escape(atob(b)));const expected=await sign(payload,key);
 if(s?.length!==expected.length||!s.split('').reduce((ok,c,i)=>ok&&c===expected[i],true))throw Error('Invalid entity review');
 const e=JSON.parse(payload);if(e.expires<Date.now())throw Error('Entity selection expired. Search again.');return e;
}
async function qloo(path:string,params:Record<string,string>,key:string,db:any){
 const url=ORIGIN+path+'?'+new URLSearchParams(params);const id=await digest(url);
 const cached=await db.prepare('SELECT payload FROM qloo_cache WHERE id=? AND expires>?').bind(id,Date.now()).first();
 if(cached)return {...JSON.parse(cached.payload),cached:true};
 // Atomic, persistent global ceiling across concurrent requests and restarts.
 const permit=await db.prepare("INSERT INTO qloo_meter(id,used) VALUES('event-v1',1) ON CONFLICT(id) DO UPDATE SET used=used+1 WHERE used<60 RETURNING used").first();
 if(!permit)throw Error('The demo API allowance is exhausted. No further provider calls will be made.');
 const r=await fetch(url,{headers:{'X-Api-Key':key,Accept:'application/json'},redirect:'manual',signal:AbortSignal.timeout(15000)});
 if(!r.ok)throw Error(r.status===429?'Qloo rate limit reached. Try later.':'Qloo is unavailable ('+r.status+'). No recommendation was generated.');
 const reader=r.body?.getReader();if(!reader)throw Error('Empty provider response');let size=0;const parts:Uint8Array[]=[];
 for(;;){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>2000000){await reader.cancel();throw Error('Provider response too large');}parts.push(value);}
 const bytes=new Uint8Array(size);let offset=0;for(const p of parts){bytes.set(p,offset);offset+=p.length;}
 const raw=new TextDecoder().decode(bytes);if(raw.includes(key))throw Error('Unsafe provider response');const data=JSON.parse(raw);if(JSON.stringify(data).includes(key)||data.error)throw Error('Invalid provider response');
 const out={data,at:new Date().toISOString(),sha256:await digest(raw),cached:false};
 await db.prepare('INSERT INTO qloo_cache(id,payload,expires) VALUES(?,?,?) ON CONFLICT(id) DO UPDATE SET payload=excluded.payload,expires=excluded.expires').bind(id,JSON.stringify(out),Date.now()+3600000).run();return out;
}
export async function GET(){
 let remaining:number|null=null;try{const row=await (env as any).DB.prepare("SELECT used FROM qloo_meter WHERE id='event-v1'").first();remaining=Math.max(0,60-Number(row?.used||0));}catch{}
 return Response.json({version:'0.3.2',mode:'Qloo live, bounded and cached',remainingLiveCalls:remaining,recordedExample:'/evidence/verified-case.json',actions:['search','evaluate'],maxGuests:6,maxCandidates:5,policy:'Within-shortlist midrank; maximize the minimum, then the mean; group confirms. No bookings.'},{headers});
}
async function boundedBody(req:Request){
 const reader=req.body?.getReader();if(!reader)throw Error('JSON required');let size=0;const parts:Uint8Array[]=[];
 for(;;){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>16000){await reader.cancel();throw Error('Request too large');}parts.push(value);}
 const bytes=new Uint8Array(size);let offset=0;for(const part of parts){bytes.set(part,offset);offset+=part.length;}return new TextDecoder('utf-8',{fatal:true}).decode(bytes);
}
export async function POST(req:Request){
 try{
 const origin=new URL(req.url).origin;if(req.headers.get('origin')!==origin) return Response.json({error:'Same-origin request required'},{status:403,headers});
 if(!req.headers.get('content-type')?.startsWith('application/json'))throw Error('JSON required');
 const body=await boundedBody(req);const input=JSON.parse(body);
 const key=(env as any).QLOO_API_KEY,db=(env as any).DB;if(!key||!db)throw Error('Live connection is not configured');
 if(input.action==='search'){
  const {query,type}=input;if(typeof query!=='string'||!query.trim()||query.length>120||/[\x00-\x1f]/.test(query)||!['movie','book','artist','place','tv_show','podcast'].includes(type))throw Error('Enter a public title or place name');
  const r=await qloo('/search',{query:query.trim(),types:'urn:entity:'+type,take:'3'},key,db);if(!Array.isArray(r.data.results)||r.data.results.length>10)throw Error('Invalid search response');
  const matches=[];for(const e of r.data.results){if(typeof e.name!=='string'||typeof e.entity_id!=='string')throw Error('Invalid entity');const p=e.properties||{};matches.push(await issue({id:e.entity_id.toLowerCase(),name:e.name.slice(0,500),type,address:typeof p.address==='string'?p.address.slice(0,500):'',description:typeof p.description==='string'?p.description.slice(0,500):'',year:p.release_year||''},key));}
  return Response.json({matches,at:r.at,cached:r.cached,sha256:r.sha256},{headers});
 }
 if(input.action==='evaluate'){
  const {guests,candidates,budget,access}=input;
  if(!Array.isArray(guests)||guests.length<2||guests.length>6||!Array.isArray(candidates)||candidates.length<2||candidates.length>5||typeof budget!=='number'||!Number.isFinite(budget)||budget<0||budget>10000||typeof access!=='boolean'||input.reviewed!==true)throw Error('Review 2–6 tastes, 2–5 places and a valid budget');
  const seeds=[];for(const g of guests){if(g.reviewed!==true)throw Error('Confirm every guest choice');seeds.push(await verify(g.proof,key));}
  const places=[];for(const c of candidates){const e=await verify(c.proof,key);if(e.type!=='place')throw Error('Candidates must be places');places.push({...c,entity:e});}
  if(new Set(places.map(c=>c.entity.id)).size!==places.length)throw Error('Choose distinct places');
  const excluded=places.map(c=>({id:c.entity.id,name:c.entity.name,reason:feasible(c,budget,access)})).filter(c=>c.reason);
  const eligible=places.filter(c=>!feasible(c,budget,access));if(eligible.length<2)return Response.json({status:'needs_information',excluded,message:'At least two places must satisfy all reviewed constraints.'},{headers});
  const ids=eligible.map(c=>c.entity.id).sort();const evidence=[];const matrix=[];
  for(const seed of seeds){const r=await qloo('/v2/insights',{'filter.type':'urn:entity:place','signal.interests.entities':seed.id,'filter.results.entities':ids.join(','),take:String(ids.length)},key,db);
   const entities=r.data.results?.entities;if(!Array.isArray(entities)||entities.length>10)throw Error('Invalid affinity response');const scores:Record<string,number>={};
   for(const e of entities){const id=e.entity_id?.toLowerCase(),score=e.affinity??e.query?.affinity;if(!ids.includes(id)||id in scores||typeof score!=='number'||!Number.isFinite(score))throw Error('Invalid affinity evidence');scores[id]=score;}
   const missing=ids.filter(id=>!(id in scores));if(missing.length)return Response.json({status:'needs_information',message:'Qloo has incomplete taste evidence for this shortlist. Replace the listed place or choose another cultural preference.',missing:eligible.filter(c=>missing.includes(c.entity.id)).map(c=>c.entity.name),excluded},{headers});
   matrix.push(scores);evidence.push({seed:seed.name,affinities:scores,at:r.at,sha256:r.sha256,cached:r.cached});
  }
  const ranking=rankGroup(matrix,ids).map(r=>({...r,entity:eligible.find(c=>c.entity.id===r.id).entity,price:eligible.find(c=>c.entity.id===r.id).price}));
  return Response.json({status:'proposal',ranking,excluded,evidence,tied:ranking.filter(r=>r.minimum===ranking[0].minimum&&r.mean===ranking[0].mean).map(r=>r.id),requiresGroupConfirmation:true,bookingPerformed:false,limitation:'Relative ranks are a decision policy, not satisfaction probabilities. Prices and access are host-reported and not independently verified.'},{headers});
 }
 throw Error('Unknown action');
 }catch(e){const message=e instanceof Error?e.message:'Request failed';const safe=/^(Invalid|Review|Confirm|Choose|Enter|JSON|Request|Same|Live|Entity|Qloo|The demo|Provider|Empty|Unsafe|No discriminating|Incomplete|Candidates|Unknown)/.test(message)?message:'Connection failed. No recommendation was generated.';return Response.json({status:'blocked',error:safe},{status:400,headers});}
}
