import './globals.css';
export const metadata={title:'TasteBridge — Find your common ground',description:'A Qloo-powered group decision tool. Reviewed tastes, real cultural affinity, explicit constraints and a fair shared shortlist.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en"><body>{children}</body></html>;}
