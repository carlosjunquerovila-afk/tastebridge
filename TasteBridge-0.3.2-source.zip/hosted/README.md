# TasteBridge 0.3.0 — hosted Qloo decision tool

Carlosjv. MIT-licensed experimental group decision tool. This hosted application replaces the former static landing experience; the original explicitly synthetic lab remains at `/lab/index.html`.

## Behavior

Review a public cultural preference for each of 2–6 guests, review 2–5 place search results including their addresses, and enter current host-reported prices/access facts. The tool applies budget, accessibility and veto constraints first, queries Qloo for each guest over the same feasible shortlist, then maximizes the lowest within-query midrank and breaks ties using the mean. Tied leaders remain explicitly identified. Users confirm the final proposal. No booking is performed.

Qloo affinities are not satisfaction probabilities; neither cross-query raw affinity comparability nor independent verification of prices/accessibility is claimed. Missing or constant affinity evidence blocks a proposal. Entity selection tokens are authenticated and expire after an hour; fact reviews expire after 24 hours. Changing any input clears the displayed proposal.

## Hosting and secrets

Vinext/Cloudflare Workers with a D1 binding `DB`. `QLOO_API_KEY` is a server-only secret managed through Sites, never source code. The sole provider destination is `https://hackathon.api.qloo.com`; redirects are rejected. Requests time out after 15 seconds and responses are limited to 2 MB. The durable `qloo_meter` table enforces 60 total provider calls for this demo revision across restarts/concurrent requests. This is an application limit, not a claim about the provider's quota. No automatic refill or retry. Search and affinity responses are cached for one hour; records contain public cultural entity data, not user names. Hosting does not use a model API.

## Development

Install dependencies using the supported Sites helper; run `node test-policy.mjs` for decision/constraint checks. Generate D1 migrations with `npm run db:generate`. Build through the Sites build helper. Both schema and generated SQL are versioned. GET `/api/taste` describes the bounded tool interface; POST accepts `search` and `evaluate`. Same-origin required. This is a deterministic agentic decision tool, not a claim that a deployed autonomous LLM agent has been tested.

## Verification limits

Build and pure decision-policy tests pass. The original Python adapter authenticated against Qloo. A real cross-domain Insights request returned incomplete evidence and correctly caused abstention. Browser UI visual QA is unavailable in this execution environment. Public URL readiness and live hosted calls must be verified after deployment. The upstream public GitHub repository describes the earlier Python runtime until synchronized; do not claim this source revision is already published there.

## Availability and policy audit — 0.3.2

The home page now includes an interactive **recorded Qloo evidence** replay from the verified 19 October run. It requires no new provider call and is explicitly distinguished from live search. The two test profiles disagree; recomputation returns a tie. Applying a veto leaves insufficient options and causes abstention. This preserves a usable, honest evidence walkthrough if the live allowance is exhausted; it does not remove the live quota limitation or substitute for the live demo requirement.

`node benchmark-policy.mjs` exhaustively enumerates 216 synthetic strict ordinal profiles for three guests and three options. Against a mean-only midrank baseline, max-min changes the choice in 27 cases (12.5%), improves the minimum in those 27, and leaves it equal in 189. Average minimum-rank gain is 0.0625, while average mean-rank sacrifice is 0.013889 (maximum 1/6). These are designed-policy properties on synthetic preferences, not a Qloo/LLM accuracy comparison or evidence of real user satisfaction. Results are at `/evidence/synthetic-policy-benchmark.json`.

POST request bodies are now bounded while streaming, before parsing, at 16,000 bytes. API metadata reports the remaining live allowance. The recorded replay is never substituted silently for a live query.
