# Prepared Devpost update — TasteBridge (entry 1241226)

Status: prepared text; not yet saved to Devpost and not submitted.

Tagline: Different tastes. One shared plan. A Qloo-powered tool that helps groups find common ground without ignoring the quietest voice.

Demo URL: https://tastebridge-carlosjv.zrm7tv2zmj.chatgpt.site
Repository: https://github.com/carlosjunquerovila-afk/tastebridge
License: MIT

## Inspiration

A group outing can satisfy the loudest person while everyone else quietly compromises. Generic recommendations rarely explain whose tastes were represented, whether the places meet hard constraints, or when the evidence is too weak to choose. TasteBridge makes those trade-offs visible.

## What it does

A host reviews a cultural preference for each of two to six guests, selects two to five real places, and records current price and accessibility facts. TasteBridge excludes options that violate the budget, required access or any group veto. It then asks Qloo for each guest’s cultural affinity over the same feasible shortlist and proposes the strongest common ground.

The tool prioritizes the lowest within-shortlist guest rank, then the mean. A tie stays a tie: the group decides. Unknown facts or incomplete affinity evidence prompt another review rather than a fabricated recommendation. Nothing is booked automatically.

## How we built it

The public app uses a React/Vinext interface, server-side Cloudflare Workers and D1 storage. Qloo Search resolves cultural titles and places; Qloo Insights supplies the cross-domain taste evidence. Address and description help distinguish similarly named places. Signed entity selections prevent arbitrary client-side replacements, and edited inputs invalidate earlier proposals.

A persistent application call ceiling, bounded responses, fixed provider origin, redirect rejection and cached evidence protect the demo. The Qloo key remains a server-side secret. The product is a deterministic agentic decision tool with explicit search/evaluate actions; we do not claim a separately deployed LLM agent.

## Challenges we addressed

Real testing exposed identically named museums in different countries, incomplete affinity coverage, and a transport incompatibility in the hosted runtime. We exposed location details, preserved abstention when evidence is incomplete, and corrected the transport without allowing redirects. We also prevent a delayed evaluation response from being shown after the host changes inputs.

## What we verified

A full hosted HTTP run completed four real Qloo searches and two real Insights calls. The profiles disagreed, so the interface received an explicitly tied shortlist instead of a false consensus. Preferences and prices in that technical test were synthetic operator inputs; Qloo entity and affinity results were real. Anonymous access to the public homepage/API was verified. Ten hosted policy checks and 52 Python regression tests passed.

These checks establish integration and decision-policy behavior, not superior satisfaction, a winning benchmark or independently verified venue facts. Browser visual testing remains pending.

## What we learned

Cultural intelligence is useful when it is coupled to a decision process that can say “we do not know.” Raw affinities across different queries are not assumed comparable; TasteBridge uses an explicitly declared within-shortlist ranking policy and leaves final agreement to people.

## What is next

Broader venue coverage, usability testing with real groups, a benchmark against mean-only and generic recommendations, and a durable judge-access allowance appropriate to confirmed provider limits. The current experimental demo uses a bounded 60-call application allowance; a busy demo can exhaust it.

## Added availability and decision-policy evidence

The public demo includes a clearly labelled, dated replay of real Qloo evidence. It keeps a useful walkthrough available without consuming live calls and never disguises recorded data as a fresh response. In216 exhaustive synthetic3guest/3option ordinal profiles, the max-min policy improves the minimum rank in27 cases versus a mean-only policy, at a measurable cost to the mean. This is a policy trade-off, not evidence of higher actual satisfaction.
